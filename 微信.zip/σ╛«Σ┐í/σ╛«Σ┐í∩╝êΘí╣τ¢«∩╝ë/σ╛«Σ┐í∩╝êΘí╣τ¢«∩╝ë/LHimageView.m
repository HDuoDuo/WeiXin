//
//  LHimageView.m
//  微信（项目）
//
//  Created by 千锋 on 16/2/29.
//  Copyright (c) 2016年 刘航. All rights reserved.
//

#import "LHimageView.h"

@implementation LHimageView
{
    //声明三个变量，用来保存传过来的对象及消息
    SEL _action;
    id _target;
    LHEvent _event;
}
//调用方法时保存
-(void)addTarget:(id)target action:(SEL)action forControlEvents:(LHEvent)event
{
    _action=action;
    _target=target;
    _event = event;
}
//按下按钮时,相当于touchdown
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (_event==LHEventTouchDown) {
        if ([_target respondsToSelector:_action]) {
            [_target performSelector:_action withObject:self];
        }
        
        
    }
}
//当按钮弹起时
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (_event==LHEventTouchUpInside)
    {
        if ([_target respondsToSelector:_action])
        {
            [_target performSelector:_action withObject:self];
        }
    }

}

@end
