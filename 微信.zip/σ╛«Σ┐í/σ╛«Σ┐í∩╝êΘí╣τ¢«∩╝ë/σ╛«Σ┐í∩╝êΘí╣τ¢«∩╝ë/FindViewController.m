//
//  FindViewController.m
//  微信（项目）
//
//  Created by liuhang on 16-2-28.
//  Copyright (c) 2016年 刘航. All rights reserved.
//

#import "FindViewController.h"
#import "LHbuttonView.h"
#import "friendroundViewController.h"
#define heightH 50
#define margin 20
@interface FindViewController ()

@end

@implementation FindViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //创建界面
    [self creatUI];
    
}
#pragma mark --创建界面
-(void)creatUI
{
    //添加朋友圈条目
    LHbuttonView * friendsround = [[LHbuttonView alloc]initWithFrame:CGRectMake(0, 64 +margin, self.view.frame.size.width         , heightH)];
    //设置tag值
    friendsround.tag = 100;
    friendsround.backgroundColor = [UIColor whiteColor];
    friendsround.imageview.image = [UIImage imageNamed:@"ff_IconShowAlbum@2x"];
    [self.view addSubview:friendsround];
    friendsround.label.text = @"朋友圈";
   
    //添加一个图片view在朋友圈条目上
    UIImageView * friendroundview = [[UIImageView alloc]initWithFrame:CGRectMake(320, 5, 40, 40)];
    friendroundview.image = [UIImage imageNamed:@"ff_IconShowAlbum@2x"];
    [friendsround addSubview:friendroundview];
    
    // 添加点击事件
    [friendsround addTarget:self action:@selector(findonclicked:) forControlEvents:LHEventTouchDown];
    
    //=====创建一个“新的朋友”这个对象======
    LHbuttonView * QRCode = [[LHbuttonView alloc]initWithFrame:CGRectMake(0, 64+ margin * 2 + heightH, self.view.frame.size.width, heightH)];
    //设置tag值
    QRCode.tag = 101;
    // 添加点击事件
    [QRCode addTarget:self action:@selector(findonclicked:) forControlEvents:LHEventTouchDown];
    //设置图片
    QRCode.imageview.image = [UIImage imageNamed:@"ff_IconQRCode@2x.png"];
    QRCode.label.text = @"扫一扫";
    //添加到界面上
    [self.view addSubview:QRCode];
    //设置背景色
    QRCode.backgroundColor = [UIColor whiteColor];
    //设置下线的颜色
    QRCode.myline.backgroundColor = [UIColor colorWithRed:230/255.0f green:230/255.0f blue:230/255.0f alpha:1];
    //添加方法
    QRCode.userInteractionEnabled=YES;
    //=======创建“群聊”的button对象======
    LHbuttonView * newfrind1 = [[LHbuttonView alloc]initWithFrame:CGRectMake(0, 64 + 2 * heightH + 2*margin, self.view.frame.size.width, heightH)];
    //设置tag值
    newfrind1.tag = 102;
    // 添加点击事件
    [newfrind1 addTarget:self action:@selector(findonclicked:) forControlEvents:LHEventTouchDown];
    //设置图片
    newfrind1.imageview.image = [UIImage imageNamed:@"ff_IconShake@2x"];
    //设置文本
    newfrind1.label.text = @"摇一摇";
    //设置背景色
    newfrind1.backgroundColor = [UIColor whiteColor];
    //添加到界面上
    [self.view addSubview:newfrind1];
       //====添加一个button对象，显示“标签”======
    LHbuttonView * buttonlabel = [[LHbuttonView alloc]initWithFrame:CGRectMake(0, 64 + 3*heightH +3* margin, self.view.frame.size.width, heightH)];
    //设置tag值
    buttonlabel.tag = 103;
    // 添加点击事件
    [buttonlabel addTarget:self action:@selector(findonclicked:) forControlEvents:LHEventTouchDown];
    //添加图片
    buttonlabel.imageview.image = [UIImage imageNamed:@"ff_IconLocationService@2x"];
    //设置文本
    buttonlabel.label.text = @"附近的人";
    //设置背景颜色
    buttonlabel.backgroundColor =
    [UIColor whiteColor];
       //添加到界面上
    [self.view addSubview:buttonlabel];
    //===添加一个button对象，显示“公众号”===
    LHbuttonView * buttonpeople = [[LHbuttonView alloc]initWithFrame:CGRectMake(0, 64 + 4 *heightH + 4 * margin, self.view.frame.size.width, heightH)];
    //设置tag值
    buttonpeople.tag = 104;
    // 添加点击事件
    [buttonpeople addTarget:self action:@selector(findonclicked:) forControlEvents:LHEventTouchDown];
    //添加图片
    buttonpeople.imageview.image = [UIImage imageNamed:@"CreditCard_ShoppingBag@2x"];
    //设置文本
    buttonpeople.label.text = @"购物";
    //设置背景颜色
    buttonpeople.backgroundColor =
    [UIColor whiteColor];
    //添加到界面上
    [self.view addSubview:buttonpeople];
    //设置下线的颜色
    buttonpeople.myline.backgroundColor = [UIColor colorWithRed:230/255.0f green:230/255.0f blue:230/255.0f alpha:1];
    //===添加一个button对象，显示“游戏”===
    LHbuttonView * buttongame = [[LHbuttonView alloc]initWithFrame:CGRectMake(0, 64 + 5 *heightH + 4 * margin, self.view.frame.size.width, heightH)];
    //设置tag值
    buttongame.tag = 105;
    // 添加点击事件
    [buttongame addTarget:self action:@selector(findonclicked:) forControlEvents:LHEventTouchDown];
    //添加图片
    buttongame.imageview.image = [UIImage imageNamed:@"MoreGame@2x"];
    //设置文本
    buttongame.label.text = @"游戏";
    //设置背景颜色
    buttongame.backgroundColor =
    [UIColor whiteColor];
    //添加到界面上
    [self.view addSubview:buttongame];


}
#pragma mark -- 朋友圈按钮点击事件
-(void)findonclicked:(LHbuttonView *)button
{
    if (button.tag==100) {
        //添加朋友圈视图控制器对象
        friendroundViewController * friendround = [[friendroundViewController alloc]init];
        //push时隐藏分栏
        friendround.hidesBottomBarWhenPushed=YES;
        //push出另一个界面
        [self.navigationController pushViewController:friendround animated:YES];
    }
    
    if (button.tag == 101) {
        NSLog(@"点击了扫伊奥");
    }
     
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
