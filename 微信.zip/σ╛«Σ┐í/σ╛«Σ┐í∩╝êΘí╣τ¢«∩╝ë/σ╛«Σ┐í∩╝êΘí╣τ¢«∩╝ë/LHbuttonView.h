//
//  LHbuttonView.h
//  微信（项目）
//
//  Created by liuhang on 16-2-28.
//  Copyright (c) 2016年 刘航. All rights reserved.
//

#import <UIKit/UIKit.h>
//创建一个枚举，保存事件机制
typedef enum : NSUInteger {
    LHEventTouchDown,
    LHEventTouchUpInside,
} LHEvent;

@interface LHbuttonView : UIView

@property(nonatomic,strong) UIImageView * imageview;
@property(nonatomic,strong) UILabel * label;
@property (nonatomic,strong) UIImageView * myline;
-(void)addTarget:(id)target action:(SEL)action forControlEvents:(LHEvent)event;
@end
