//
//  LHTabBarController.m
//  微信（项目）
//
//  Created by liuhang on 16-2-28.
//  Copyright (c) 2016年 刘航. All rights reserved.
//

#import "LHTabBarController.h"
#import "WeiXinViewController.h"
#import "ContactViewController.h"
#import "FindViewController.h"
#import "MineViewController.h"
@interface LHTabBarController ()

@end

@implementation LHTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    //设置微信视图对象
    WeiXinViewController * weixin  = [[WeiXinViewController alloc]init];
    
    //设置微信视图的title
    weixin.title = @"微信";
    UINavigationController * nav1 = [[UINavigationController alloc]initWithRootViewController:weixin];
     //设置角标
    [nav1.tabBarItem setBadgeValue:[NSString stringWithFormat:@"%d",8]];
    //设置分栏控制器的背景图片
    [nav1.tabBarItem setImage:[[UIImage imageNamed:@"tabbar_mainframe@2x.png"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [nav1.tabBarItem setSelectedImage:[[UIImage imageNamed:@"tabbar_mainframeHL@2x.png"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    //设置联系人视图对象控制器
    ContactViewController * contact = [[ContactViewController alloc]init];
    
    //设置联系人视图的title
    contact.title = @"通讯录";
    //设置分栏控制器的背景图片
    [contact.tabBarItem setImage:[[UIImage imageNamed:@"tabbar_contacts@2x.png"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [contact.tabBarItem setSelectedImage:[[UIImage imageNamed:@"tabbar_contactsHL@2x.png"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    //添加联系人导航控制器
    UINavigationController * nav2 = [[UINavigationController alloc]initWithRootViewController:contact];
   
    //添加“发现”视图对象
    FindViewController * find = [[FindViewController alloc]init];
    
    //设置title
    find.title = @"发现";
    //设置分栏控制器的背景图片
    [find.tabBarItem setImage:[[UIImage imageNamed:@"tabbar_discover@2x.png"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [find.tabBarItem setSelectedImage:[[UIImage imageNamed:@"tabbar_discoverHL@2x.png"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    //添加导航控制器对象
    UINavigationController * nav3 = [[UINavigationController alloc]initWithRootViewController:find];
    //添加“我”视图控制器对象
    MineViewController * mine = [[MineViewController alloc]init];
    
    //设置title
    mine.title = @"我";
    //设置分栏控制器的背景图片
    [mine.tabBarItem setImage:[[UIImage imageNamed:@"tabbar_me@2x.png"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [mine.tabBarItem setSelectedImage:[[UIImage imageNamed:@"tabbar_meHL@2x.png"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    //添加导航控制器对象
    UINavigationController * nav4 = [[UINavigationController alloc]initWithRootViewController:mine];
    //给分栏控制器添加对象
        self.viewControllers=@[nav1,nav2,nav3,nav4];
        //选择状态下
    [[UITabBarItem appearance]setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor greenColor]} forState:UIControlStateSelected];
    //设置导航条字体显示颜色
    [[UIBarButtonItem appearance]setTintColor:[UIColor whiteColor]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
