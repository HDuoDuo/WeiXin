//
//  friendroundViewController.m
//  微信（项目）
//
//  Created by 千锋 on 16/3/2.
//  Copyright (c) 2016年 刘航. All rights reserved.
//

#import "friendroundViewController.h"

@interface friendroundViewController ()
{
    
}

@end

@implementation friendroundViewController
#pragma mark --生命周期
- (void)viewDidLoad {
    [super viewDidLoad];
    //创建页面
    [self creatUI];
}
#pragma mark --creatUI
-(void)creatUI
{
    //设置返回按钮
    UIButton * backitem = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 50, 50)];
    [backitem setImage:[UIImage imageNamed:@"backitem"] forState:UIControlStateNormal];
    UIBarButtonItem * leftitem = [[UIBarButtonItem alloc]initWithCustomView:backitem];
    [self.navigationItem setLeftBarButtonItem:leftitem];
    //添加事件
    [backitem addTarget:self action:@selector(backitemonclicked) forControlEvents:UIControlEventTouchUpInside];
   // 设置相机按钮
    UIImageView * cameraitem = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 40, 40)];
    cameraitem.image = [UIImage imageNamed:@"camera.png"];
    UIBarButtonItem * rightitem = [[UIBarButtonItem alloc]initWithCustomView:cameraitem];
[self.navigationItem setRightBarButtonItems:@[rightitem]];
    //设置titleview
    UILabel * titleviewlabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 375, 50)];
    titleviewlabel.text = @"朋友圈";
    [titleviewlabel setTextColor:[UIColor whiteColor]];
    [titleviewlabel setFont:[UIFont boldSystemFontOfSize:20]];
    [self.navigationItem setTitleView:titleviewlabel];
    
}
-(void)backitemonclicked
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
