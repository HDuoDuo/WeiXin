//
//  MyTableViewCell.m
//  微信（项目）
//
//  Created by 千锋 on 16/3/3.
//  Copyright (c) 2016年 刘航. All rights reserved.
//

#import "MyTableViewCell.h"
#define margin 7.0f
#define margin1 13.0f
#define Height 50.0f
@implementation MyTableViewCell
{
    //声明成员变量
    UIImageView * _iconView;
    UILabel *  _namelabel;
}
//创建cell时会调用这个方法
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        //实例化成员变量
        _iconView = [[UIImageView alloc]init];
        [self.contentView addSubview:_iconView];
        _iconView.backgroundColor = [UIColor redColor];
        //添加到cell上
        _namelabel = [[UILabel alloc]init];
        [self.contentView addSubview:_namelabel];
        _namelabel.backgroundColor = [UIColor greenColor];
    }
    return self;
}
-(void)layoutSubviews
{
    //计算每个子控件的位置
    //头像的frame
    CGFloat iconX = margin1;
    CGFloat iconY =margin;
    CGFloat iconW = Height-2*margin;;
    CGFloat iconH =iconW;
    _iconView.frame = CGRectMake(iconX, iconY, iconW, iconH);
    //昵称的frame
    CGFloat nameX = iconW + 2*margin1;
    CGFloat nameY = iconY+margin;
    CGFloat nameW = iconW * 5;
    CGFloat nameH = iconH - 2 * margin;
    _namelabel.frame = CGRectMake(nameX, nameY, nameW, nameH);
    
    
}




- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
