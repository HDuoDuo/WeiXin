//
//  friendroundViewController.h
//  微信（项目）
//
//  Created by 千锋 on 16/3/2.
//  Copyright (c) 2016年 刘航. All rights reserved.
//

#import "LHViewController.h"

@interface friendroundViewController : LHViewController

@end
