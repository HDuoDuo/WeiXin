//
//  MyTableViewCell.h
//  微信（项目）
//
//  Created by 千锋 on 16/3/3.
//  Copyright (c) 2016年 刘航. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTableViewCell : UITableViewCell

@end
