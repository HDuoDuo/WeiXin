//
//  LHViewController.m
//  微信（项目）
//
//  Created by liuhang on 16-2-28.
//  Copyright (c) 2016年 刘航. All rights reserved.
//

#import "LHViewController.h"
#import "jiahaoViewController.h"
#import "LHTabBarController.h"
@interface LHViewController ()
{
    UIImageView * try;
}
@end

@implementation LHViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //设置所有视图的背景颜色
    self.view.backgroundColor = [UIColor colorWithRed:230/255.0f green:230/255.0f blue:230/255.0f alpha:1];
    //设置导航控制器的item
    NSInteger i = 8;
    NSString * messagenumber = [[NSString alloc]initWithFormat:@"微信(%ld)",i];
    //创建label，作为导航控制器左
    UILabel * leftBaritem = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 80, 40)];
    [leftBaritem setFont:[UIFont systemFontOfSize:18]];
    [leftBaritem setTextColor:[UIColor whiteColor]];
    leftBaritem.text=messagenumber;
    [self.view addSubview:leftBaritem];
    UIBarButtonItem * item1 = [[UIBarButtonItem alloc]initWithCustomView:leftBaritem];
    [self.navigationItem setLeftBarButtonItem:item1];
    //设置导航条右按钮
    UIBarButtonItem * weixinitemAdd = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(onclicked:)];
    //设置tag值
    weixinitemAdd.tag = 0;
//设置导航条的右按钮
    UIBarButtonItem * weixinitemSearch = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemSearch target:self action:@selector(onclicked:)];
    //设置tag值
    weixinitemSearch.tag = 1;
    [self.navigationItem setRightBarButtonItems:@[weixinitemAdd,weixinitemSearch]];
    self.navigationItem.title=@"";
    //设置全部导航条背景色
    [self.navigationController.navigationBar setBarStyle:UIBarStyleBlackTranslucent];
    
    
}
-(void)onclicked:(UIBarButtonItem *)button
{
    if (button.tag == 1) {
        NSLog(@"点击了加号按钮");
    }
    if (button.tag== 0)
    {
//
        
        //创建一个透明的button在该界面上
        UIButton * button = [[UIButton alloc]initWithFrame:[UIScreen mainScreen].bounds];
        button.backgroundColor = [UIColor clearColor];
        
         [self.navigationController.view addSubview:button];
        //添加事件
        [button addTarget:self action:@selector(onclickedbutton:) forControlEvents:UIControlEventTouchUpInside];
        //创建加号按钮的UI
        
        try = [[UIImageView alloc]initWithFrame:CGRectMake(360, 64, 0, 0)];
        try.backgroundColor = [UIColor blackColor];
        [self.navigationController.view addSubview:try];
        [UIView animateWithDuration:0.1f animations:^{
            try.frame =CGRectMake(360, 64, -170, 200);
        }];
       
        UIButton * qunliaoBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 170, 40)];
        [qunliaoBtn setImage:[UIImage imageNamed:@"faqiqunliao"] forState:UIControlStateNormal];
        [try addSubview:qunliaoBtn];
        
        
        
    }
}
//实现右上角button的点击事件
-(void)onclickedbutton:(UIButton *)button
{
    [UIView animateWithDuration:0.1f animations:^{
        try.frame =CGRectMake(360, 64, 0, 0);
    }completion:^(BOOL finished) {
        [button removeFromSuperview];
        
    }];
}
-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
