//
//  ContactViewController.m
//  微信（项目）
//
//  Created by liuhang on 16-2-28.
//  Copyright (c) 2016年 刘航. All rights reserved.
//

#import "ContactViewController.h"
#import "LHbuttonView.h"
#define heightH 50
@interface ContactViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView * _tableview;
 
}
@end

@implementation ContactViewController
#pragma mark -- 懒加载
-(NSMutableArray *)imageArray
{
    if (_imageArray==nil) {
        _imageArray=[[NSMutableArray alloc]initWithObjects:@"plugins_FriendNotify@2x",@"add_friend_icon_addgroup@2x",@"Contact_icon_ContactTag@2x",@"gongzhonghao@2x",@"gongzhonghao@2x",nil];
    }
    return _imageArray;
}
-(NSMutableArray *)dataArray
{
  
    if (_dataArray==nil) {
        _dataArray = [[NSMutableArray alloc]initWithObjects:@"新的朋友",@"群聊",@"标签",@"公众号",@"爱酒,爱美人",nil];
       }
    return _dataArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
      //创建tableview
    [self creatTableView];
}
#pragma mark --创建tableView
-(void)creatTableView
{
    //默认分组的时候，每个组之间有一定的间隔
    _tableview = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStylePlain];
    _tableview.dataSource = self;
    _tableview.delegate = self;
    [self.view addSubview:_tableview];
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 20;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section==0)
    {
        return 4;
    }
    else if (section==1)
    {
        return self.dataArray.count-4;
    }
    return 0;
   
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //在复用队中去找可以复用的cell
    static NSString * cellID = @"cellID";
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell==nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    }
    //刷新数据
    cell.textLabel.text =self.dataArray[indexPath.row];
  ;
    [cell.imageView setImage:[UIImage imageNamed:self.imageArray[indexPath.row]]];
    cell.imageView.frame = CGRectMake(0, 0, 20, 5);
    //4.返回cell
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
