//
//  jiahaoViewController.m
//  微信（项目）
//
//  Created by 千锋 on 16/3/4.
//  Copyright (c) 2016年 刘航. All rights reserved.
//

#import "jiahaoViewController.h"

@interface jiahaoViewController ()

@end

@implementation jiahaoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    [self creatUI];
}
-(void)creatUI
{
    
    //创建“发起群聊”
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
