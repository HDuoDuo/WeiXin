//
//  LHbuttonView.m
//  微信（项目）
//
//  Created by liuhang on 16-2-28.
//  Copyright (c) 2016年 刘航. All rights reserved.
//

#import "LHbuttonView.h"
#define margin 7.0f
#define margin1 13.0f
@interface LHbuttonView ()
{
        //声明三个变量，用来保存传过来的对象及消息
    SEL  _action;
    id  _target;
    LHEvent _event;
}
@end
@implementation LHbuttonView
//调用方法时保存
-(void)addTarget:(id)target action:(SEL)action forControlEvents:(LHEvent)event
{
    _action=action;
    _target=target;
    _event = event;
}
//按下按钮时,相当于touchdown
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (_event==LHEventTouchDown) {
        if ([_target respondsToSelector:_action]) {
            [_target performSelector:_action withObject:self];
        }
        
        
    }
}
//当按钮弹起时
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (_event==LHEventTouchUpInside)
    {
        if ([_target respondsToSelector:_action])
        {
            [_target performSelector:_action withObject:self];
        }
    }
    
}




-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        //实例化imageview
        self.imageview = [[UIImageView alloc]init];
        [self addSubview:self.imageview];
        
        //实例化label
        self.label = [[UILabel alloc]init];
        [self addSubview:self.label];
        //实例化line
        self.myline = [[UIImageView alloc]init];
        [self addSubview:self.myline];
        
       
    }
    return self;
}


-(void)layoutSubviews
{

    //创建imageview对象
    CGFloat imageviewX =margin1 + self.frame.origin.x;
    CGFloat imageviewY =margin;
    CGFloat imageviewH = self.frame.size.height - 2 * margin;
    CGFloat imageviewW= imageviewH;
    self.imageview.frame =CGRectMake(imageviewX,imageviewY, imageviewW,imageviewH);
    //创建label对象
    CGFloat labelX=imageviewX + imageviewW +margin1;
    CGFloat labelY=imageviewY;
    CGFloat labelW = self.frame.size.width-imageviewW-2*margin1;
    CGFloat labelH=imageviewH;
    
    self.label.frame =CGRectMake(labelX, labelY, labelW, labelH);
    [self.label setFont:[UIFont systemFontOfSize:14]];
    //创建一条线
 self.myline.frame = CGRectMake(margin1, imageviewY+imageviewH + margin-0.3, imageviewW+labelW-margin,0.3);
}

@end
